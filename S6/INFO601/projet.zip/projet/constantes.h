#ifndef CONSTANTES_H
#define CONSTANTES_H

#define LI 30
#define COL 15
#define LI_SEM 5
#define COL_SEM 5

#define MAX_V 10

#define KEY_SHM 4545
#define KEY_SEM 2564
#define KEY_MSG 3579

#endif