#include "structures.h"
#include "fonctions.h"
/*
void recevoirmsg(){

}

void supprimermsg(){

}

void envoyermsg(){
    
}*/