#ifndef FONCTIONS_H
#define FONCTIONS_H

#include <stdlib.h>     /* Pour exit, EXIT_FAILURE, EXIT_SUCCESS */
#include <stdio.h>      /* Pour printf, perror */
#include <sys/msg.h>    /* Pour msgget, msgsnd, msgrcv */
#include <errno.h>      /* Pour errno */
#include "structures.h"
/*
void recevoirmsg();
void supprimermsg();
void envoyermsg();*/

#endif