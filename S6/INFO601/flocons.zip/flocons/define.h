#ifndef DEFINE_H
#define DEFINE_H 

#define H_INFO 3
#define H_ETAT 6
#define LARGEUR 17
#define HAUTEUR 5
#define POSX 20
#define POSY 5
#define LIGNE 15
#define COLONNE 30

#endif //DEFINE_H   
