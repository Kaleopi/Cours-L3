#include "ncurses.h"
#include "shm_map.h"
#include "messages.h"
#include "defines.h"

void afficher_carte(carte_t *);
int creer_file();
void error_args();