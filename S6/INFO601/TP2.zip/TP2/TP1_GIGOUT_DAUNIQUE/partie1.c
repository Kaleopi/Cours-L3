#include <stdlib.h>     /* Pour EXIT_FAILURE */
#include <ncurses.h>    /* Pour printw, attron, attroff, COLOR_PAIR, getch */
#include <math.h>
#include <time.h>
#include <stdio.h>
#include <unistd.h> 
#include <fcntl.h> 
#include <string.h>
#include "ncurses.h"

int exists(const char *fname)
{
  int i=0;
   int ret=0;
    int file;
    file = open(fname,O_RDONLY|O_WRONLY);
    if(file!=-1)
    {
      off_t old=lseek(file,0,SEEK_CUR);
      off_t end=lseek(file,0,SEEK_END);

    while(old!=end){
        old =lseek(file,i,SEEK_SET);
        i++;
      }
        close(file);
        return i-1;
    }else{
    file=open(fname,O_CREAT|O_WRONLY| O_APPEND,0777);
      char *res="";
        printf("%d",file);
      printf ("entrez une val :");
      int bouya=scanf("%s",res);
      if (bouya!=0){
        for(int i =0 ;i<strlen(res);i++){
        ret=write(file,res,sizeof(res));
        }
      }
      
      return ret;
    }

    
}

int main() {
  char* kek="test";


    int taille=exists(kek);
    printf("%d\n",taille);
}