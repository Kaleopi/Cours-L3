var searchData=
[
  ['vmdcolrangigm1',['VMDCOLRANGIGM1',['../vmdKeywords_8h.html#a92c1bfadcf967bec5c64dba0919b2fd7af7c54e03a3568cde07356b35319b0e6c',1,'vmdKeywords.h']]],
  ['vmdcolrangigm2',['VMDCOLRANGIGM2',['../vmdKeywords_8h.html#a92c1bfadcf967bec5c64dba0919b2fd7a4938ae4f569439bd35ed3de1ceb9d68c',1,'vmdKeywords.h']]]
];
