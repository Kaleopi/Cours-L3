var searchData=
[
  ['_7elocaldata',['~LocalData',['../classLocalData.html#ad0c90984b05728e80471e1dc9e74d78d',1,'LocalData']]],
  ['_7enode',['~Node',['../classNode.html#aa0840c3cb5c7159be6d992adecd2097c',1,'Node']]],
  ['_7eprogdata',['~ProgData',['../classProgData.html#a70e4b8804c57b49367d9d90ca2aaab3f',1,'ProgData']]],
  ['_7eresults',['~Results',['../classResults.html#a0547c32c2061192a72cad9db694ffb16',1,'Results']]]
];
