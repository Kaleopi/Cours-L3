var searchData=
[
  ['init',['init',['../classLocalData.html#a43f9a7efaaf0d4aeb19d6caa65382dbb',1,'LocalData']]],
  ['intermolecular',['intermolecular',['../classResults.html#a00ddb9dbefefe6ee4c1c3731933a88ee',1,'Results']]]
];
