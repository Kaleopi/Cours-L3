var indexSectionsWithContent =
{
  0: "acdfgiklmnoprsuv~",
  1: "lnpr",
  2: "glmnoprv",
  3: "acgilnoprsuv~",
  4: "k",
  5: "cdflmprv"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "enums",
  5: "enumvalues"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Enumerations",
  5: "Enumerator"
};

