var searchData=
[
  ['localdata',['LocalData',['../classLocalData.html',1,'']]]
];
