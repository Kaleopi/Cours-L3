var searchData=
[
  ['validate',['validate',['../classProgData.html#ac39f6fa170fd4280cc98e2960bdbff20',1,'ProgData']]]
];
