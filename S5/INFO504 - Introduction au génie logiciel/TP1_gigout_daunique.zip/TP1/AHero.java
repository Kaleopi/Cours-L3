public abstract class AHero{
  //Declarations
  protected String nom;
  protected int pointDeVie;
  protected int exp;
  protected int niveau;
  protected int force;
  protected int dexterite;
  protected int magie;

  //Méthodes
  abstract 

}
