// TP SUJET 01

/*
Question 1

Avantages:
          -Pas à se soucier de l'héritage et des problème d'accès
          -Pas de couplage / tout centralisé
          -attributs privés
          -constructeur OK
          -getter
Inconvénients:
          -Trop Générique
          -Différentiation des différentes classes difficile
          -Maintenance complexe/rajout de nouvelle classe possédant de nouvelle Méthodes et/ou attributs nécessite la redéfinition de cette classe
          -Limite l'évolution(augmente la complexité)
          -1 attribut en trop (ptMagie)
          -Pas de possibilité de partager les caractéristique(valeur par def/construct avec mo=ins de paramètres)

On sait pas:
          -Constructeur par copie
          -set nom aucune information
          -gestion PV/EXP/NIVEAU
*/
