#ifndef KRUSKAL_H
#define KRUSKAL_H
#include "arete.h"
#include "graphe.h"

void prim_tri(Graphe *g);
#endif