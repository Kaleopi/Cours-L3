typedef enum COULEUR COULEUR;
enum COULEUR{
  BLANC,
  GRIS,
  NOIR
}
