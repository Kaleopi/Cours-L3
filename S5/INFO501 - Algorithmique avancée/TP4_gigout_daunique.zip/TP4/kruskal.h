#ifndef KRUSKAL_H
#define KRUSKAL_H
#include "arete.h"
#include "graphe.h"

Arete** generer_acpm_kruskal_tableau(Arete ** t);
#endif
