#ifndef BELLMANFORD.H
#define BELLMANFORD.H
#include "graphe.h"

void BellmanFord(struct Graphe* g, int src);
