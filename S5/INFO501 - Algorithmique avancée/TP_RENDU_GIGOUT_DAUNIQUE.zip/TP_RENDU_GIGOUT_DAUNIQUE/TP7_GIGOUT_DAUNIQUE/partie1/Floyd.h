#ifndef FLOYD.H
#define FLOYD.H
#include "graphe.h"
void afficher_soluce(int dist[][V]);
void floydWarshall (int graph[][V]);
